// store abbreviation value in let variable
let provinceObj, provName, flag, desc, cities = [], size;

//apply function for layout loading from province.html
function loadLayout(){
    let full_Name = `SaiyedAsma`;
    let citizenCountry =  `Canada`;
    let userName =`saiyedas`;
    let myId = `991578249`;
    let myProgram = `Computer System Technology-Software Development and Network Engineering`;

//that is returns an Element object representing the element whose id property matches the specified string
    
document.getElementById('hT').innerHTML = `Winter 2023/Assignment-2  ${full_Name} from ${citizenCountry}`;

document.querySelector('footer').innerHTML = `My username: ${userName} / My ID: ${myId} / My Advanced Diploma is: ${myProgram}`;

let pName = localStorage.getItem("province");
//fetch request by xhttp
 const xhttp = new XMLHttpRequest();
 xhttp.open('GET', '/A2_Asma/json/provinces.json', true);
 xhttp.send();
 xhttp.onload = function (){
 data = this.responseText;
 let provinces = JSON.parse(data);
 let output1 = "";

for(let p of provinces){
output1 +=`

<div class="province button" id="${p.pName}" onclick="provinceDetails(this)">

<img src="${p.flag1}" alt="${p.flag1}">
<p class="prname">${p.pName}</p>
                        
</div>`; 
            
console.log('size of cities', size);
console.log('province name', p.pName);
console.log('cities', p.cities);
console.log('city 1', p.cities[1]);
console.log('province obj', provinceObj);
        }
document.querySelector('.provinceList').innerHTML = output1;
       
    }    
    
}

//call function
function provinceDetails(btn) {
    const provinceName = btn.id;

// set cities name value into local storage
    localStorage.setItem('province', provinceName);

    
//window.location.href property returns the URL of the current page
    window.location.href = 'pages/province.html';
  }