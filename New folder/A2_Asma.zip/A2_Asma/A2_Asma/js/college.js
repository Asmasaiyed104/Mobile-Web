
//apply function for layout loading from province.html
function loadLayout(){

    let full_Name = `SaiyedAsma`;
    let citizenCountry =  `Canada`;
    let userName =`saiyedas`;
    let myId = `991578249`;
    let myProgram = `Computer System Technology-Software Development and Network Engineering`;
    
    
//that is returns an Element object representing the element whose id property matches the specified string
    document.getElementById('hT').innerHTML = `Winter 2023/Assignment-2 ${full_Name} from ${citizenCountry}`;

    document.querySelector('footer').innerHTML = `My username: ${userName} / My ID: ${myId} / My Program: ${myProgram}`;

    //store collegeNamevalue into localstorage so we can access data
    let collegeNameLoc = localStorage.getItem("collegeName");


   //fetch request by xhttp
    const xhttp = new XMLHttpRequest();
    xhttp.open('GET', '../json/colleges.json', true);
    xhttp.send();
    xhttp.onload = function (){
    data = this.responseText;
    let collegeDetails = JSON.parse(data);
    let output = "";
    let outputCourses ="";
    let courses = [];
    
    
// for loop for displaying collegeDetails
    for(let co of collegeDetails){
    if(co.collegeName == collegeNameLoc){
    console.log('college name: ', co.collegeName);
    courses = co.courses;
    size = courses.length;

    for(let i=0; i<size; i++){
    outputCourses +=`
   <p class="courses" id="${co.courses[i]}">${co.courses[i]}</p>`;
  }
            
output += `
 <div class="college" id="${co.collegeName}">
<p class="description">${co.description}</p>
<p class="coursesTitle">Courses in ${co.collegeName}</p> <p>${outputCourses}</p></div>`;
}
 }
console.log("courses", courses);


// console.log("courses size", size);
document.querySelector('.collegeDetails').innerHTML = output;
document.getElementById('clName').innerHTML = collegeNameLoc;
    }
}
//call function
function collegeDetails(btn){
const collegeName = btn.id;

// set college name value into local storage
localStorage.setItem('collegeName', collegeName);

//window.location.href property returns the URL of the current page
window.location.href = '../pages/college.html';
}

////window.location.href property returns the URL of the previous page
const previousPage = () => {
window.location.href = '../pages/city.html';
  }