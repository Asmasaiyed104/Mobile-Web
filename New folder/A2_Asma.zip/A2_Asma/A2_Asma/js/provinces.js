// store abbreviation value in let variable
let provAbbreviation;

//apply function for layout loading from province.html
function loadLayout() {
  let full_Name = `SaiyedAsma`;
  let citizenCountry = `Canada`;
  let userName = `saiyedas`;
  let myId = `991578249`;
  let myProgram = `Computer System Technology-Software Development and Network Engineering`;

  //that is returns an Element object representing the element whose id property matches the specified string

  document.getElementById("hT"
).innerHTML = `Winter 202/ Assignment-2  ${full_Name} from ${citizenCountry}`;
  
document.querySelector("footer"
).innerHTML = `My username: ${userName} / My ID: ${myId} / My Program: ${myProgram}`;

//store province value inti localstorage so we can access data

  let pName = localStorage.getItem("province");

//fetch request by xhttp 

const xhttpProv = new XMLHttpRequest();
xhttpProv.open("GET", "../json/provinces.json", true);
  xhttpProv.send();
  xhttpProv.onload = function () {
   data = this.response;
   provJSONdata = JSON.parse(data);
  let output1 = "";
  let output2 = "";

  // for loop for displaying province data
  for (let p of provJSONdata) {
      if (p.pName === pName) {
        output1 += `
                
                    <img id="imgflag" src="${p.flag}" alt="${p.flag}"/>
                    <p class="provDescription">${p.description}</p></div>`;
  //for loop for displaying cities data
        for (let c of p.cities) {
          output2 += `
                    <div class="city button" id="${c}" onclick="cityDetails(this)">
                    <p class="ctname">${c}</p>
                    
                    </div>`;
        }
      }
    }

    document.querySelector(".provDetails").innerHTML = output1;
    document.querySelector(".cityList").innerHTML = output2;
    document.getElementById("pName").innerHTML = pName;
  };
}

//call function
function cityDetails(btn) {
  const ctName = btn.id;

// set cities name value into local storage
  localStorage.setItem("cityName", ctName);

//window.location.href property returns the URL of the current page

  window.location.href = "../pages/city.html";
}
//window.location.href property returns the URL of the previous page

const previousPage = () => {
  window.location.href = "../index.html";
};
