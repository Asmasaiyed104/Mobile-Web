//apply function for layout loading from province.html
function loadLayout() {
let full_Name = `SaiyedAsma`;
let citizenCountry = `Canada`;
let userName = `saiyedas`;
let myId = `991578249`;
let myProgram = `Computer System Technology-Software Development and Network Engineering`;
 
//that is returns an Element object representing the element whose id property matches the specified string
document.getElementById('hT').innerHTML = `Winter 2023 Assignment #2 for ${full_Name} from ${citizenCountry}`;

document.querySelector('footer').innerHTML = `My Login: ${userName} / My ID: ${myId} / My Program: ${myProgram}`;

//store cities value inti localstorage so we can access data
let cityNameLoc = localStorage.getItem("cityName");

//fetch request by xhttp
const xhttp = new XMLHttpRequest();
 xhttp.open('GET', '../json/cities.json', true);
 xhttp.send();
 xhttp.onload = function () {
 data = this.responseText;
 let cityDetails = JSON.parse(data);
 let output = "";
 let outputColleges = "";
 let colleges = [];
// for loop for displaying cities data 
for (let d of cityDetails) {
if (d.cityName == cityNameLoc) {
console.log("Colleges at here: ", d.colleges);
                
if (d.colleges == null || d.colleges.length == 0) {
output += `

<div class="city" id="${d.cityName}">
<h4 class="subtitle">Description</h4>
<p class="description">${d.description}</p>
<h4 class="subtitle">Coordinate</h4>
<p class="subtitle">Colleges in ${d.cityName}</p>
<p class="noCol">Sorry, no college at here.</p>
</div>`;
 }
else {
console.log('city obj', d);
for (let col of d.colleges) {
outputColleges += `
<button class="collegeBtn" id="${col}" onclick="collegeDetails(this)"> ${col}</button>`;
 }
                    
output += `
<div class="city" id="${d.cityName}">
<h4 class="subtitle">Description</h4>
 <p class="description">${d.description}</p>
 <h4 class="subtitle">Coordinate</h4>
<p class="subtitle">Colleges in ${d.cityName}</p>
<p class="colleges">${outputColleges}</p>
 </div>  `;
 }

               
}
 }
document.querySelector('.cityDetails').innerHTML = output;
 document.getElementById('cityName').innerHTML = cityNameLoc;

    }
// fetch API of holidays using fetch 
fetch(`https://date.nager.at/api/v2/publicholidays/2020/CA`)
    .then((res) => {
    console.log('res', res);
    return res.json();
        })
  .then((JSONholidays) => {
console.log('holidays JSONholidays', JSONholidays);

 let provAbbreviation = localStorage.getItem('provinceAbbreviation');


console.log('provAbbreviation: ', provAbbreviation);
            
let filteredHolidays = [];
            
let outputHolidays = "";
for (let h of JSONholidays) {
 console.log("holiday counties", h.counties);
if (h.counties == null) {
 console.log("empty counties");
filteredHolidays.push(h);
                } 
else {
for (let i = 0; i < h.counties.length; i++) {
                        
console.log("counties: ", h.counties[i]);
if (h.counties[i] === "`CA-${provAbbreviation}`") {
filteredHolidays.push(h);
 }
 }
}

}
 console.log("Filtered holidays", filteredHolidays);


for (let fh of filteredHolidays) {
               
    
console.log("holiday:", fh.name);
outputHolidays += `<div class="holiday"><p>${fh.name}</p><p>Date:${fh.date}<p></div><hr>`;
            }
 console.log("output holidays:", outputHolidays)
 document.querySelector('.holidays').innerHTML = outputHolidays;

})
.catch(err => alert("not holidays"))


}

function collegeDetails(btn) {
const collegeName = btn.id;

localStorage.setItem('collegeName', collegeName);

window.location.href = '../pages/college.html';
}

const previousPage = () => {
window.location.href = '../pages/province.html';
}